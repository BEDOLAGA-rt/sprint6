public enum Status {
    NEW,
    DONE,
    IN_PROGRESS
}