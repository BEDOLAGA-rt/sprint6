

public enum TaskType {
    TASK,
    EPIC,
    SUBTASK
}